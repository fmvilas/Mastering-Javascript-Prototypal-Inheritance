Classical Inheritance vs Modular Patterns
=========================================

Slides from my conference on Classical Inheritance, Prototypical Inheritance and Modular Patterns at Itnig, Barcelona.

[Check it out here!](http://fmvilas.github.io/Classical-Inheritance-vs-Modular-Patterns)

* Twitter: [@fmvilas](http://www.twitter.com/fmvilas)
* Google+: [+FranciscoMendezVilas](https://plus.google.com/+FranciscoMendezVilas)